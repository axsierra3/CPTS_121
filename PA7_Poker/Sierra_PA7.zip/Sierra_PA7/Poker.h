// guard code
#ifndef POKER_H
#define POKER_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct card {
	int faceIndex;
	int suitIndex;

} Card;

typedef struct hand {
	Card cardArr[5]; //player's hand

} Hand;

void shuffle(int wDeck[][13]); //shuffles 2d array of 13

void deal(const int wDeck[][13], Hand* h);

void printHand(const char* wFace[], const char* wSuit[], Hand* h);

void displayRules();

void countFaces(Hand* hand1, int faceCt[13]);

void countSuits(Hand* hand1, int suitCt[4]);

int containsPair(Hand* hand1);

int containsTwoPairs(Hand* hand1);

int contains3OfKind(Hand* hand1);

int contains4OfKind(Hand* hand1);

int containsFullHouse(Hand* hand1); //3 of a kind and 2 and a pair

int containsflush(Hand* hand1); //5 of same suit (the 13)

int containsStraight(Hand* hand1); //5 cards of consecutive face vals


#endif // guard code end

#pragma once
