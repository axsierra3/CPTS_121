#include "Poker.h"



int main(void)
{
	int choice = 3;

	/* initialize suit array */
	const char* suit[4] = { "Hearts", "Diamonds", "Clubs", "Spades" };

	/* initialize face array */
	const char* face[13] = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight",
		"Nine", "Ten", "Jack", "Queen", "King" };

	/* initalize deck array */
	int deck[4][13] = { 0 };

	srand((unsigned)time(NULL)); /* seed random-number generator */



	printf("\nWELCOME TO POKER!");

	Hand playerHand;
	Hand computerHand;
	do {
		shuffle(deck);

		printf("\nWould you like to 1. View the game rules 2. Play the game 3. Exit\n\n");
		scanf("%d", &choice);

		if (choice == 1) {
			displayRules();
		}
		else if (choice == 3) {
			break;
		}
		
		
		printf("\nDealing your hand: \n");
		deal(deck, &playerHand);
		printHand(face, suit, &playerHand);

		int rollNum = 0;
		int cardToReplace = 0;
		printf("\n\nWould you like to replace any cards? Max 3 (1/0) : \n");
		scanf("%d", &choice);
		if (choice == 1)
		{
			printf("Enter the card to replace: \n");
			scanf("%d", &cardToReplace);

			deal(deck, &playerHand);
		}


		printf("\nDealing computer's hand: \n"); //
		deal(deck, &computerHand);


		checkWinner(&playerHand, &computerHand);
	} while (choice != 3);

	return 0;
}
